@echo off
echo Running BAIT Algorithm with CIFAR10 and DenseNet121
python run.py --alg bait --data CIFAR10 --model densenet121 --nStart 2000 --nQuery 2500 --nEnd 50000 > bait_cifar10_densenet121_log.txt 2>&1

echo Running BADGE Algorithm with CIFAR10 and DenseNet121
python run.py --alg badge --data CIFAR10 --model densenet121 --nStart 2000 --nQuery 2500 --nEnd 50000 > badge_cifar10_densenet121_log.txt 2>&1

echo Experiments completed!
