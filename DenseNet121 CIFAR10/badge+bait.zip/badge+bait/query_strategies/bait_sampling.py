import numpy as np
from torch.utils.data import DataLoader
from .strategy import Strategy
import numpy as np
import gc
from scipy.spatial.distance import cosine
import sys
import gc
from scipy.linalg import det
from scipy.linalg import pinv as inv
from copy import copy as copy
from copy import deepcopy as deepcopy
import torch
from torch import nn
import torchfile
from torch.autograd import Variable
import resnet
import vgg
import torch.optim as optim
import pdb
from torch.nn import functional as F
import argparse
import torch.nn as nn
from collections import OrderedDict
from scipy import stats
import numpy as np
import scipy.sparse as sp
from itertools import product
from sklearn.base import BaseEstimator, ClusterMixin, TransformerMixin
from sklearn.metrics.pairwise import euclidean_distances
from sklearn.metrics.pairwise import pairwise_distances_argmin_min
from sklearn.utils.extmath import row_norms, squared_norm, stable_cumsum
from sklearn.utils.sparsefuncs_fast import assign_rows_csr
from sklearn.utils.sparsefuncs import mean_variance_axis
from sklearn.utils.validation import _num_samples
from sklearn.utils import check_array
from sklearn.utils import gen_batches
from sklearn.utils import check_random_state
from sklearn.utils.validation import check_is_fitted
from sklearn.utils.validation import FLOAT_DTYPES
from sklearn.metrics.pairwise import rbf_kernel as rbf
from sklearn.exceptions import ConvergenceWarning
from sklearn.metrics import pairwise_distances


def select(X, K, fisher, iterates, lamb=1, nLabeled=0):
    """Select K indices using a forward‑selection / backward‑pruning scheme.

    Parameters
    ----------
    X : torch.Tensor
        Embeddings of shape (N, dim).
    K : int
        Number of points to select.
    fisher : torch.Tensor
        Fisher information matrix (dim, dim).
    iterates : torch.Tensor
        Regularization matrix (dim, dim).
    lamb : float, optional
        Regularization weight.
    nLabeled : int, optional
        Number of already labeled points.
    """
    numEmbs = X.shape[0]
    indsAll = []
    dim = X.shape[-1]
    rank = X.shape[-2]

    # Ensure double precision on GPU
    X = X.type(torch.float64)
    fisher = fisher.type(torch.float64).cuda()
    iterates = iterates.type(torch.float64)

    # Regularized inverse (safe with pinv fallback)
    reg_mat = lamb * torch.eye(dim, dtype=torch.float64, device='cuda') + iterates * nLabeled / (nLabeled + K)
    try:
        currentInv = torch.inverse(reg_mat)
    except RuntimeError:
        currentInv = torch.linalg.pinv(reg_mat)

    # Scale embeddings as in original implementation
    X = X * np.sqrt(K / (nLabeled + K))

    # forward selection, over-sample by 2x
    print('forward selection...', flush=True)
    over_sample = 2
    for i in range(int(over_sample *  K)):

        # chunked trace calculation to avoid GPU OOM
        traceEst = []
        chunk_size = 5000
        for chunk_idx in range(0, len(X), chunk_size):
            xt_ = X[chunk_idx:chunk_idx+chunk_size].cuda()
            innerInv = torch.inverse(torch.eye(rank, dtype=torch.float64).cuda() + xt_ @ currentInv @ xt_.transpose(1, 2)).detach()
            innerInv[torch.where(torch.isinf(innerInv))] = torch.sign(innerInv[torch.where(torch.isinf(innerInv))]) * np.finfo('float64').max
            trace_chunk = torch.diagonal(xt_ @ currentInv @ fisher @ currentInv @ xt_.transpose(1, 2) @ innerInv, dim1=-2, dim2=-1).sum(-1)
            traceEst.append(trace_chunk.cpu())
            del xt_, innerInv, trace_chunk
            torch.cuda.empty_cache()
        traceEst = torch.cat(traceEst, dim=0).detach().numpy()
        gc.collect()

        # get the smallest unselected item
        for j in np.argsort(traceEst)[::-1]:
            if j not in indsAll:
                ind = j
                break

        indsAll.append(ind)
        print(i, ind, traceEst[ind], flush=True)
       
        # commit to a low-rank update
        xt_ = X[ind].unsqueeze(0).cuda()
        innerInv = torch.inverse(torch.eye(rank, dtype=torch.float64).cuda() + xt_ @ currentInv @ xt_.transpose(1, 2)).detach()
        currentInv = (currentInv - currentInv @ xt_.transpose(1, 2) @ innerInv @ xt_ @ currentInv).detach()[0]
        currentInv = (currentInv + currentInv.t()) / 2.0

    # backward pruning
    print('backward pruning...', flush=True)
    for i in range(len(indsAll) - K):

        # select index for removal
        xt_ = X[indsAll].cuda()
        innerInv = torch.inverse(-1 * torch.eye(rank, dtype=torch.float64).cuda() + xt_ @ currentInv @ xt_.transpose(1, 2)).detach()
        traceEst = torch.diagonal(xt_ @ currentInv @ fisher @ currentInv @ xt_.transpose(1, 2) @ innerInv, dim1=-2, dim2=-1).sum(-1)
        delInd = torch.argmin(-1 * traceEst).item()
        print(len(indsAll) - i, indsAll[delInd], -1 * traceEst[delInd].item(), flush=True)


        # low-rank update (woodbury identity)
        xt_ = X[indsAll[delInd]].unsqueeze(0).cuda()
        innerInv = torch.inverse(-1 * torch.eye(rank, dtype=torch.float64).cuda() + xt_ @ currentInv @ xt_.transpose(1, 2)).detach()
        currentInv = (currentInv - currentInv @ xt_.transpose(1, 2) @ innerInv @ xt_ @ currentInv).detach()[0]
        currentInv = (currentInv + currentInv.t()) / 2.0

        del indsAll[delInd]

    del xt_, innerInv, currentInv
    torch.cuda.empty_cache()
    gc.collect()
    return indsAll

class BaitSampling(Strategy):
    def __init__(self, X, Y, idxs_lb, net, handler, args):
        super(BaitSampling, self).__init__(X, Y, idxs_lb, net, handler, args)        
        self.lamb = args['lamb']

    def query(self, n):
        idxs_unlabeled = np.arange(self.n_pool)[~self.idxs_lb]

        # get low-rank point-wise fishers
        xt = self.get_exp_grad_embedding(self.X, self.Y)

        # get fisher
        print('getting fisher matrix...', flush=True)
        batchSize = 1000 # should be as large as gpu memory allows
        nClass = torch.max(self.Y).item() + 1
        fisher = torch.zeros(xt.shape[-1], xt.shape[-1])
        rounds = int(np.ceil(len(self.X) / batchSize))
        for i in range(int(np.ceil(len(self.X) / batchSize))):
            xt_ = xt[i * batchSize : (i + 1) * batchSize].cuda()
            # Reshape to avoid [batch, dim, dim] explicit creation which causes massive OOM
            z = xt_.view(-1, xt_.shape[-1])
            op = torch.matmul(z.t(), z) / len(xt)
            fisher = fisher + op.detach().cpu()
            del xt_, z, op
            torch.cuda.empty_cache()
            gc.collect()

        # get fisher only for samples that have been seen before
        nClass = torch.max(self.Y).item() + 1
        init = torch.zeros(xt.shape[-1], xt.shape[-1])
        xt2 = xt[self.idxs_lb]
        rounds = int(np.ceil(len(xt2) / batchSize))
        for i in range(int(np.ceil(len(xt2) / batchSize))):
            xt_ = xt2[i * batchSize : (i + 1) * batchSize].cuda()
            z = xt_.view(-1, xt_.shape[-1])
            op = torch.matmul(z.t(), z) / len(xt2)
            init = init + op.detach().cpu()
            del xt_, z, op
            torch.cuda.empty_cache()
            gc.collect()

        chosen = select(xt[idxs_unlabeled], n, fisher, init, lamb=self.lamb, nLabeled=np.sum(self.idxs_lb))
        return idxs_unlabeled[chosen]
