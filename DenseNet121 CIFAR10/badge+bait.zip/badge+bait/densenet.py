import torch
import torch.nn as nn
import torch.nn.functional as F
import torchvision.models as models

class DenseNet121(nn.Module):
    def __init__(self, num_classes=200):
        super(DenseNet121, self).__init__()
        # Load a standard DenseNet121
        self.densenet = models.densenet121(pretrained=False)
        self.embDim = self.densenet.classifier.in_features
        # Replace classifier with Identity to get embeddings
        self.densenet.classifier = nn.Identity()
        self.projection = nn.Linear(self.embDim, 128)
        self.linear = nn.Linear(128, num_classes)
        self.embDim = 128
        
    def forward(self, x):
        emb = self.densenet(x)
        emb = F.relu(self.projection(emb))
        out = self.linear(emb)
        return out, emb
        
    def get_embedding_dim(self):
        return self.embDim

def get_densenet121(num_classes=200):
    return DenseNet121(num_classes=num_classes)
